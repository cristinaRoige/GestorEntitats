-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Temps de generació: 13-04-2017 a les 11:50:34
-- Versió del servidor: 10.1.21-MariaDB
-- Versió de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dades: `entitats`
--

-- --------------------------------------------------------

--
-- Estructura de la taula `activitat`
--

CREATE TABLE `activitat` (
  `IdActivitat` int(11) NOT NULL,
  `nomActivitat` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `descripcio` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dataActivitat` date NOT NULL,
  `horaActivitat` date NOT NULL,
  `publica` tinyint(1) NOT NULL,
  `NumAforament` int(10) UNSIGNED ZEROFILL DEFAULT NULL,
  `Aforament` tinyint(1) NOT NULL,
  `tipusActivitat` int(10) NOT NULL,
  `idJornada` int(10) NOT NULL,
  `idLocalitzacio` int(10) NOT NULL,
  `idImatge` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `alerta`
--

CREATE TABLE `alerta` (
  `IdAlerta` int(10) NOT NULL,
  `Nom` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Descripcio` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Text` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `blog`
--

CREATE TABLE `blog` (
  `IdBlog` int(10) NOT NULL,
  `titol` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `descripcio` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dataPublicacio` date NOT NULL,
  `activitatBlog` int(10) DEFAULT NULL,
  `idComentari` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `comentari`
--

CREATE TABLE `comentari` (
  `IdComentari` int(10) NOT NULL,
  `titol` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `contingut` text COLLATE utf8_unicode_ci NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `entitat`
--

CREATE TABLE `entitat` (
  `IdEntitat` int(10) NOT NULL,
  `Nom` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Adreca` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Telefon` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `CorreuElectronic` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `Inici` text COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `IdTipusEntitat` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `entitatjornada`
--

CREATE TABLE `entitatjornada` (
  `IdEntitatJornada` int(10) UNSIGNED ZEROFILL NOT NULL,
  `idEntitat` int(10) DEFAULT NULL,
  `idJornada` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `entitatpersona`
--

CREATE TABLE `entitatpersona` (
  `IdEntitatPersona` int(10) NOT NULL,
  `IdEntitat` int(10) DEFAULT NULL,
  `IdPersona` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `imatge`
--

CREATE TABLE `imatge` (
  `IdImagte` int(10) NOT NULL,
  `nomImatge` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `descripcio` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `jornada`
--

CREATE TABLE `jornada` (
  `IdJornada` int(10) NOT NULL,
  `Descripcio` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `DiesDurada` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `localitzacio`
--

CREATE TABLE `localitzacio` (
  `Idlocalitzacio` int(10) NOT NULL,
  `nomLocalitzacio` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descripcio` varchar(200) CHARACTER SET ucs2 COLLATE ucs2_unicode_ci NOT NULL,
  `Adreca` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `Poblacio` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `latitud` double NOT NULL,
  `longitud` double NOT NULL,
  `localitzacioEntitat` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `persona`
--

CREATE TABLE `persona` (
  `IdPersona` int(10) NOT NULL,
  `Usuari` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Correu` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Contrasenya` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Rol` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IdComentari` int(10) NOT NULL,
  `IdPersonaEnvia` int(10) NOT NULL,
  `idPersonaRep` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `personesactivitat`
--

CREATE TABLE `personesactivitat` (
  `IdPersonesActivitat` int(10) NOT NULL,
  `idTipusRol` int(10) DEFAULT NULL,
  `idActivitat` int(10) DEFAULT NULL,
  `idPersona` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `tipusactivitat`
--

CREATE TABLE `tipusactivitat` (
  `IdTipusActivitat` int(10) NOT NULL,
  `Descripcio` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `tipusentitat`
--

CREATE TABLE `tipusentitat` (
  `IdTipudEntitat` int(10) NOT NULL,
  `Descripcio` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de la taula `tipusrol`
--

CREATE TABLE `tipusrol` (
  `IdTipusRol` int(10) NOT NULL,
  `organitzacio` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexos per taules bolcades
--

--
-- Index de la taula `activitat`
--
ALTER TABLE `activitat`
  ADD PRIMARY KEY (`IdActivitat`),
  ADD KEY `tipusActivitat` (`tipusActivitat`),
  ADD KEY `idLocalitzacio` (`idLocalitzacio`),
  ADD KEY `idImatge` (`idImatge`),
  ADD KEY `idJornada` (`idJornada`);

--
-- Index de la taula `alerta`
--
ALTER TABLE `alerta`
  ADD PRIMARY KEY (`IdAlerta`);

--
-- Index de la taula `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`IdBlog`),
  ADD KEY `blog_ibfk_1` (`activitatBlog`),
  ADD KEY `idComentari` (`idComentari`);

--
-- Index de la taula `comentari`
--
ALTER TABLE `comentari`
  ADD PRIMARY KEY (`IdComentari`);

--
-- Index de la taula `entitat`
--
ALTER TABLE `entitat`
  ADD PRIMARY KEY (`IdEntitat`),
  ADD KEY `IdTipusEntitat` (`IdTipusEntitat`);

--
-- Index de la taula `entitatjornada`
--
ALTER TABLE `entitatjornada`
  ADD PRIMARY KEY (`IdEntitatJornada`),
  ADD KEY `idEntitat` (`idEntitat`),
  ADD KEY `idJornada` (`idJornada`);

--
-- Index de la taula `entitatpersona`
--
ALTER TABLE `entitatpersona`
  ADD PRIMARY KEY (`IdEntitatPersona`),
  ADD KEY `IdEntitat` (`IdEntitat`),
  ADD KEY `IdPersona` (`IdPersona`);

--
-- Index de la taula `imatge`
--
ALTER TABLE `imatge`
  ADD PRIMARY KEY (`IdImagte`);

--
-- Index de la taula `jornada`
--
ALTER TABLE `jornada`
  ADD PRIMARY KEY (`IdJornada`);

--
-- Index de la taula `localitzacio`
--
ALTER TABLE `localitzacio`
  ADD PRIMARY KEY (`Idlocalitzacio`),
  ADD KEY `localitzacioEntitat` (`localitzacioEntitat`);

--
-- Index de la taula `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`IdPersona`),
  ADD KEY `persona_ibfk_1` (`IdComentari`),
  ADD KEY `persona_ibfk_2` (`IdPersonaEnvia`),
  ADD KEY `persona_ibfk_3` (`idPersonaRep`);

--
-- Index de la taula `personesactivitat`
--
ALTER TABLE `personesactivitat`
  ADD PRIMARY KEY (`IdPersonesActivitat`),
  ADD KEY `idTipusRol` (`idTipusRol`),
  ADD KEY `idActivitat` (`idActivitat`),
  ADD KEY `idPersona` (`idPersona`);

--
-- Index de la taula `tipusactivitat`
--
ALTER TABLE `tipusactivitat`
  ADD PRIMARY KEY (`IdTipusActivitat`);

--
-- Index de la taula `tipusentitat`
--
ALTER TABLE `tipusentitat`
  ADD PRIMARY KEY (`IdTipudEntitat`);

--
-- Index de la taula `tipusrol`
--
ALTER TABLE `tipusrol`
  ADD PRIMARY KEY (`IdTipusRol`);

--
-- AUTO_INCREMENT per les taules bolcades
--

--
-- AUTO_INCREMENT per la taula `activitat`
--
ALTER TABLE `activitat`
  MODIFY `IdActivitat` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `alerta`
--
ALTER TABLE `alerta`
  MODIFY `IdAlerta` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `blog`
--
ALTER TABLE `blog`
  MODIFY `IdBlog` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `comentari`
--
ALTER TABLE `comentari`
  MODIFY `IdComentari` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `entitat`
--
ALTER TABLE `entitat`
  MODIFY `IdEntitat` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `entitatjornada`
--
ALTER TABLE `entitatjornada`
  MODIFY `IdEntitatJornada` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `entitatpersona`
--
ALTER TABLE `entitatpersona`
  MODIFY `IdEntitatPersona` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `imatge`
--
ALTER TABLE `imatge`
  MODIFY `IdImagte` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `jornada`
--
ALTER TABLE `jornada`
  MODIFY `IdJornada` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `localitzacio`
--
ALTER TABLE `localitzacio`
  MODIFY `Idlocalitzacio` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `persona`
--
ALTER TABLE `persona`
  MODIFY `IdPersona` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `personesactivitat`
--
ALTER TABLE `personesactivitat`
  MODIFY `IdPersonesActivitat` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `tipusactivitat`
--
ALTER TABLE `tipusactivitat`
  MODIFY `IdTipusActivitat` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `tipusentitat`
--
ALTER TABLE `tipusentitat`
  MODIFY `IdTipudEntitat` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la taula `tipusrol`
--
ALTER TABLE `tipusrol`
  MODIFY `IdTipusRol` int(10) NOT NULL AUTO_INCREMENT;
--
-- Restriccions per taules bolcades
--

--
-- Restriccions per la taula `activitat`
--
ALTER TABLE `activitat`
  ADD CONSTRAINT `activitat_ibfk_1` FOREIGN KEY (`tipusActivitat`) REFERENCES `tipusactivitat` (`IdTipusActivitat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activitat_ibfk_3` FOREIGN KEY (`idLocalitzacio`) REFERENCES `localitzacio` (`Idlocalitzacio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activitat_ibfk_4` FOREIGN KEY (`idImatge`) REFERENCES `imatge` (`IdImagte`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activitat_ibfk_5` FOREIGN KEY (`idJornada`) REFERENCES `jornada` (`IdJornada`) ON UPDATE CASCADE;

--
-- Restriccions per la taula `blog`
--
ALTER TABLE `blog`
  ADD CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`activitatBlog`) REFERENCES `activitat` (`IdActivitat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `blog_ibfk_2` FOREIGN KEY (`idComentari`) REFERENCES `comentari` (`IdComentari`) ON UPDATE CASCADE;

--
-- Restriccions per la taula `entitat`
--
ALTER TABLE `entitat`
  ADD CONSTRAINT `entitat_ibfk_1` FOREIGN KEY (`IdTipusEntitat`) REFERENCES `tipusentitat` (`IdTipudEntitat`);

--
-- Restriccions per la taula `entitatjornada`
--
ALTER TABLE `entitatjornada`
  ADD CONSTRAINT `entitatjornada_ibfk_1` FOREIGN KEY (`idEntitat`) REFERENCES `entitat` (`IdEntitat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `entitatjornada_ibfk_2` FOREIGN KEY (`idJornada`) REFERENCES `jornada` (`IdJornada`) ON UPDATE CASCADE;

--
-- Restriccions per la taula `entitatpersona`
--
ALTER TABLE `entitatpersona`
  ADD CONSTRAINT `entitatpersona_ibfk_1` FOREIGN KEY (`IdEntitat`) REFERENCES `entitat` (`IdEntitat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `entitatpersona_ibfk_2` FOREIGN KEY (`IdPersona`) REFERENCES `persona` (`IdPersona`) ON UPDATE CASCADE;

--
-- Restriccions per la taula `localitzacio`
--
ALTER TABLE `localitzacio`
  ADD CONSTRAINT `localitzacio_ibfk_1` FOREIGN KEY (`localitzacioEntitat`) REFERENCES `entitat` (`IdEntitat`) ON UPDATE CASCADE;

--
-- Restriccions per la taula `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`IdComentari`) REFERENCES `comentari` (`IdComentari`) ON UPDATE CASCADE,
  ADD CONSTRAINT `persona_ibfk_2` FOREIGN KEY (`IdPersonaEnvia`) REFERENCES `alerta` (`IdAlerta`) ON UPDATE CASCADE,
  ADD CONSTRAINT `persona_ibfk_3` FOREIGN KEY (`idPersonaRep`) REFERENCES `alerta` (`IdAlerta`) ON UPDATE CASCADE;

--
-- Restriccions per la taula `personesactivitat`
--
ALTER TABLE `personesactivitat`
  ADD CONSTRAINT `personesactivitat_ibfk_1` FOREIGN KEY (`idTipusRol`) REFERENCES `tipusrol` (`IdTipusRol`) ON UPDATE CASCADE,
  ADD CONSTRAINT `personesactivitat_ibfk_2` FOREIGN KEY (`idActivitat`) REFERENCES `activitat` (`IdActivitat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `personesactivitat_ibfk_3` FOREIGN KEY (`idPersona`) REFERENCES `persona` (`IdPersona`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
